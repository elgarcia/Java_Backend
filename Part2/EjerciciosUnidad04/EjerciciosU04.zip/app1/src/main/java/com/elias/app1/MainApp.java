package com.elias.app1;

import com.elias.applib.Library;

public class MainApp {
	public static void main(String[] args) {
		Library.Hello();
		System.out.println(Library.saySomething());
	}
}
