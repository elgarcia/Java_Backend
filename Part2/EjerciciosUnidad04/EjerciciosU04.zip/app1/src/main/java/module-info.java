module app1 {
	requires applib;
}