package com.elias.applib;

public class Library {
	public static void  Hello(){
		System.out.println("Hello World");
	}

	public static String    saySomething(){
		return "Say Something";
	}
}
