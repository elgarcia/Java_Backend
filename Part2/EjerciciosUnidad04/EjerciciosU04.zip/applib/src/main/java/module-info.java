module applib {
	exports com.elias.applib;
}