package com.elias;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class Material {
	private int id;
	private String nombre;
	private String tipo;
}
