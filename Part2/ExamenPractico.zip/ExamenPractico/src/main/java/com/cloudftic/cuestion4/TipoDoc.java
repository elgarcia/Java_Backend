package com.cloudftic.cuestion4;

public enum TipoDoc {
	LIBRO, NOVELA, ENSAYO;
}
