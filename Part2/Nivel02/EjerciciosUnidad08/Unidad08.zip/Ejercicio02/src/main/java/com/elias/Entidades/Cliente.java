package com.elias.Entidades;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class Cliente {
	private final int   id;
	private String      name;
}
