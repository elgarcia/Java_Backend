package com.elias.AppSpring.Repository;

import com.elias.AppSpring.Entity.Anotacion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AnotacionRepository extends JpaRepository<Anotacion, Integer> {
}
