package access;

import entities.Ingreso;

public interface IRepositorioIngresos {
	public void add(Ingreso ingreso);
}
